﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SzofttechZH2Gyak3
{
    public partial class FormCountryEdit : Form
    {
        public FormCountryEdit()
        {
            InitializeComponent();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void FormCountryEdit_Load(object sender, EventArgs e)
        {

        }
    }
}
