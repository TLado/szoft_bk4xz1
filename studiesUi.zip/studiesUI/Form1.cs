using Microsoft.VisualBasic.Devices;
using System.Windows.Forms;

namespace studiesUI
{
    public partial class Form1 : Form
    {
        StudiesContext context = new StudiesContext();
        public UserControl2()
        {
            InitializeComponent();

            FillDataSource();
            listBox1.DisplayMember = "Name";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FillDataSource();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null) return;
            Course course = listBox1.SelectedItem as Course;

            dataGridView1.DataSource = (from l in context.Lessons
                                        where l.CourseFk == course.CourseSk
                                        select new
                                        {
                                            Nap = l.DayFkNavigation.Name,
                                            S�v = l.TimeFkNavigation.Name,
                                            Oktat� = l.InstructorFkNavigation.Name
                                        }).ToList();
        }

        private void FillDataSource()
        {
            listBox1.DataSource = (from c in context.Courses
                                   where c.Name.Contains(textBox1.Text)
                                   select c).ToList();
        }

    }
}
